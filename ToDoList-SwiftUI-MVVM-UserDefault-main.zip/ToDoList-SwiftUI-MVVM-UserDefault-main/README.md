# ToDoList-SwiftUI-MVVM-UserDefault
ToDoList is an intuitive and powerful app developed in SwiftUI, using the MVVM (Model-View-ViewModel) architecture along with data persistence through UserDefaults. With this combination, we offer a seamless user experience and reliable storage for your tasks.
